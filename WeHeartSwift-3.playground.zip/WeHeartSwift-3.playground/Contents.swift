//: Playground - noun: a place where people can play

import UIKit

//Variables and Constants

let sum = 2 + 5
let diff = 15 - sum
let mul = diff * sum
let div = mul / diff
let modulo = 7 % 3
//because 2 * 3 + 1 = 7       +   -   *   /
let modula2 = 13 % 5

let diff2 = 5 / 2
let diff3 : Double = 5 / 2



